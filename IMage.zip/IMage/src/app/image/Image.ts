export interface Image
{
    imageId:number,
    imageUrl:String,
    productId:number
}