import { Component, OnInit } from '@angular/core';
import { ImageService } from '../../imageupload/image.service';

@Component({
  selector: 'app-zoom',
  templateUrl: './zoom.component.html',
  styleUrls: ['./zoom.component.css']
})
export class ZoomComponent implements OnInit {

  constructor(private service: ImageService ) { }

  ngOnInit() {
  }
  myThumbnail="http://localhost:5000/images/10003.jpg";
  myFullresImage="http://localhost:5000/images/10003.jpg";
  
}
