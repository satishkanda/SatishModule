import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ImageuploadComponent } from './imageupload/imageupload.component';
import { GetImageComponent } from './image/get-image/get-image.component';
import { ZoomComponent } from './image/zoom/zoom.component';


const routes: Routes = [
  {path: '', component: ImageuploadComponent},
  { path: 'get', component: GetImageComponent },
  {path:"zoom",component:ZoomComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
