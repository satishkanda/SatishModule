package com.common.feedback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeedBackCommonApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeedBackCommonApplication.class, args);
	}

}
