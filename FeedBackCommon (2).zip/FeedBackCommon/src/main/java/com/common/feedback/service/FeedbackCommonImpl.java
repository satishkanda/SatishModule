package com.common.feedback.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.common.feedback.bean.FeedbackCommon;
import com.common.feedback.dao.FeedbackCommonRepo;

@Service
public class FeedbackCommonImpl implements FeedbackCommonService{
	
	@Autowired
	private FeedbackCommonRepo repo;

	@Override
	public void byCustomer(FeedbackCommon feedback) {
		feedback.setSender(1);
		repo.save(feedback);
		
	}

	@Override
	public void byMerchant(FeedbackCommon feedback) {
		repo.save(feedback);
	}

	@Override
	public List<FeedbackCommon> getCustomerChat(int custId, int merchantId) {
		return repo.getCustomerChat(custId, merchantId);
	}

}
