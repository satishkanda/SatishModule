package com.common.feedback.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.common.feedback.bean.FeedbackCommon;

@Repository
public interface FeedbackCommonRepo extends JpaRepository<FeedbackCommon,Integer> {
	
	@Query("from FeedbackCommon where custId=:custId and merchantId=:merchantId")
	public List<FeedbackCommon> getCustomerChat(@Param("custId") int custId,@Param("merchantId") int merchantId);

}
