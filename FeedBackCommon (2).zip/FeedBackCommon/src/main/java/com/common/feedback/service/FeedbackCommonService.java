package com.common.feedback.service;

import java.util.List;

import com.common.feedback.bean.FeedbackCommon;

public interface FeedbackCommonService {

	void byCustomer(FeedbackCommon feedback);
	void byMerchant(FeedbackCommon feedback);
	
	List<FeedbackCommon> getCustomerChat(int custId,int merchantId);

}
