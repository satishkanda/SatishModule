package com.common.feedback.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(name = "chat", initialValue = 1, allocationSize = 1)
public class FeedbackCommon {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "chat")
	private int chatId;
	private int merchantId;
	private int custId;
	private String message;
	private int sender;

	public FeedbackCommon() {
		super();
	}

	public FeedbackCommon(int chatId, int merchantId, int custId, String message, int sender) {
		super();
		this.chatId = chatId;
		this.merchantId = merchantId;
		this.custId = custId;
		this.message = message;
		this.sender = sender;
	}

	public int getChatId() {
		return chatId;
	}

	public void setChatId(int chatId) {
		this.chatId = chatId;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getSender() {
		return sender;
	}

	public void setSender(int sender) {
		this.sender = sender;
	}

}
